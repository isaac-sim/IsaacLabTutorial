Selected Transfer vision policy: full robot colliders, shoulder-lift scale 0.040 rad.
Qualification: 3948/4096 placements, 96.63% clean / 96.14% noisy.
Portable deployment bundle: copy the complete leapp/ directory, retaining contract.json.
The existing deploy.py consumes its action scales. Keep the checked hardware joint map and camera setup.
CPU parity: Torch 2.10.0+cpu, LEAPP 0.7.1, 32 inputs, max error 0.0.
All training is stopped. No hardware connection was opened.
Rare rack contacts above 20 N remain; real success is unmeasured.
Full details and simulation replay: source_snapshot/docs/sim2real/DOMAIN_RANDOMIZATION.md
Inspection timelines include subsequent episodes after a world completes; outcomes.json counts only first episodes.
